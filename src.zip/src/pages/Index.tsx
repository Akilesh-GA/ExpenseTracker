import Welcome from "./Welcome";

const Index = () => {
  return <Welcome />;
};

export default Index;
